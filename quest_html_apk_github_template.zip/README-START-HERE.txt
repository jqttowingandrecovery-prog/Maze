QUEST HTML TO APK — START HERE

This is a starter Android wrapper that builds an APK using GitHub Actions.
It does NOT modify your original index.html.

PHONE-FRIENDLY STEPS
1. Extract this ZIP on your phone.
2. Create a new GitHub repository (choose Private if you want).
3. Upload ALL files and folders from this ZIP into the repository, keeping the folder structure.
4. In the repository, open Settings > Actions > General. Under "Actions permissions", allow actions if required, then Save.
5. Open the Actions tab and run "Build Quest HTML APK" (or push/upload a file to trigger it).
6. Open the finished workflow run, scroll to Artifacts, and download "quest-html-debug-apk".
7. Extract the downloaded artifact ZIP. It contains app-debug.apk.

PUT YOUR PROJECT FILES HERE
Copy your existing index.html and every folder/file it uses into:
app/src/main/assets/www/

Example:
app/src/main/assets/www/index.html
app/src/main/assets/www/js/...
app/src/main/assets/www/images/...

Do not put your files at the repository root. Put them in that www folder.
Keep a separate backup of the original project.

IMPORTANT VR LIMITATION
This packages the page in a fullscreen Android WebView. It may display your existing side-by-side stereo layout, but it does NOT add native Quest VR, head tracking, controller support, or guarantee that the Quest will treat it as an immersive VR app. Test it on your Quest 3. WebXR-based features generally won't work in a basic WebView.

This workflow creates a DEBUG APK for testing/sideloading, not a store-ready signed release. Store publication requires additional Quest-specific checks and signing/release setup.
